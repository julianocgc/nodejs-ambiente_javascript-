function soma(a, b) {
  console.log(a + b);
}

export default soma;
