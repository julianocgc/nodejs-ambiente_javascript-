const path = require("path");

const extension = path.extname("arquivo.php");

console.log(extension);
